import UsersCard from "./Components/users";
import './App.css';

import React, { Component } from 'react'

class App extends Component {
  constructor(props) {
    super(props)

    // Set initial state
    this.state = {
      userData: [],
      loading: true
    }

    this.updateUserData = this.updateUserData.bind(this)
  }

  updateUserData() {
    const apiUrl = "https://reqres.in/api/users?page=1";
    fetch(apiUrl)
      .then(response => response.json())
      .then((data) => {
        this.setState({
          userData: data.data,
          loading: false
        })
        console.log(data.data);
      })
      .catch((error) => {
        console.error(error)
      })
  }

  render() {
    return (
      <div>
        <nav>
          <div className="box">
            <div className="row">
              <div className="column1">
                <h2>LGM Users</h2>
              </div>
              <div className="column2">
                <button onClick={this.updateUserData}>Get Users</button>
              </div>
            </div>
          </div>
        </nav>
        <div className="box2">
          <UsersCard loading={this.state.loading} users={this.state.userData} />
        </div>
      </div>
    )
  }
}

export default App;
